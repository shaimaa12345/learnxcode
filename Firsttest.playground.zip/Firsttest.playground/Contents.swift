
let firstArray :[String] = ["5", "10", "15", "20", "25", "30", "35","40","45","50"]
let firstElement = firstArray.first
//let LastThree = Array(firstArray.last[6...8])
let lastthree=firstArray[6...9]

print(firstElement)
print(lastthree)

var stringarray :[String] = ["Shaimaa", "Saleh", "Mohammed"]

var anyValue : Any = ["a", "s", true]
stringarray.append("Maha")
anyValue.append("Shakia")
anyValue.insert(1, at: 3)


var array1 =  [1, 2, 3, 4, 5, 6, 7,
8,9,10,11,12,13,14,15,16,17,18,19,20]

let oddArray2=[1,3,5,7,9,11,13,15,17,19]
let names = ["Ali","Ahmed","Sami","Mohammed"]

//let mergedArrays = Array(array1, oddArray2)
let mergedArrays = (array1 + oddArray2).sorted()
//let merge=[firstitem+lastitem]

/*
var pastries:[String] = ["cookie","cupcake","donut","clair"]
pastries[0] //subscripting
//pastries[13]// out of range
let firstThree = Array(pastries[1...3])
//firstThree[0]
pastries.append("icecream")
//pastries.removeAll()

//var pastries:[String]=[]
pastries.append("cookies")
pastries.append("lolipop")
pastries.append("eclair")
pastries += ["cupdacke","cake","honeycake"]

//append or + for adding elements

//-----------videos up
import UIKit

//var greeting = "Hello, Shaimaa"

//let myarray: [String]=["shaimaa","ahmed","ali","mohamed"]
var myarray: [String] = []
myarray.append("huda")
myarray.append("saleh")
myarray += ["shams","ahmed","yosuef"]
// or myarray.insert("toto" ,at:0)
let firstthree=Array(myarray[1...3])
let lastthree=myarray[6...10]
print(lastthree)
firstthree[0]
//myarray[0]
//myarray[13]



//myarray.removeall()
myarray.isEmpty
myarray.count
myarray.first
if let first=myarray.first{
    print(first)
}
myarray.contains("eman")

let removedtwo=myarray.remove(at:2)
let removedlast=myarray.removeLast()
removedtwo
removedlast

//myarray.swapAt(1,2)
//----------------------
var sh1: [String]
var sh2 = [String?] ()
var sh3 = ["Saleh","Ahmed","Mohammed","Shams","Eman"]

//print("array0:" \(array0)s")
print(sh3)
//var array1[String]=("a","b","c","d","e","f","g","h","i","J")


/*
let testarray1[String] =("a","b","c","d","e","f","g","h","i","J")
testarray.count
//testarray.contains("z")

print(testarray.first)
//print(test.last)

let lastThree=Array(test[7...9])
if let first=test.first{

print(first,lastThree)
}
 var firstArray: [String]=[]
firstArray.append("shaimaa")
let Second: [Any]=[]

let teamone = Array(test[4...7])

//









*/
 */
